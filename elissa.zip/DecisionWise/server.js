import express from "express";
import helmet from "helmet";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
const root = path.dirname(fileURLToPath(import.meta.url));
const allowed = new Set(["en", "fr", "rw"]);
app.use(helmet({
  contentSecurityPolicy: { directives: {
    defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
    fontSrc: ["'self'", "data:", "https://fonts.gstatic.com"], imgSrc: ["'self'", "data:"],
    connectSrc: ["'self'", "https://translation.googleapis.com"], objectSrc: ["'none'"]
  }}
}));
app.use(express.json({limit:"40kb"}));
app.use(express.static(path.join(root,"public")));
app.get("/api/status", (_req,res) => res.json({ok:true,translationConfigured:Boolean(process.env.GOOGLE_TRANSLATE_API_KEY)}));
app.post("/api/translate", async (req,res) => {
  const {texts,target,source="en"} = req.body || {};
  if (!Array.isArray(texts) || texts.length < 1 || texts.length > 100 || !texts.every(x => typeof x === "string" && x.length <= 2000))
    return res.status(400).json({error:"Send 1–100 text strings, each no longer than 2,000 characters."});
  if (!allowed.has(target) || !allowed.has(source) || target === source)
    return res.status(400).json({error:"Unsupported source or target language."});
  const key = process.env.GOOGLE_TRANSLATE_API_KEY;
  if (!key || key.includes("put_your_"))
    return res.status(503).json({error:"Translation setup required: add your Google Cloud Translation API key to the server .env file."});
  try {
    const url = new URL("https://translation.googleapis.com/language/translate/v2");
    url.searchParams.set("key",key);
    const upstream = await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({q:texts,source,target,format:"text"}),signal:AbortSignal.timeout(15000)});
    const data = await upstream.json().catch(()=>({}));
    if (!upstream.ok) {
      console.error("Google Translation error:",upstream.status,data?.error?.message || "");
      return res.status(502).json({error:"Translation provider rejected the request. Check the API key, billing, and API enablement."});
    }
    const result = data?.data?.translations;
    if (!Array.isArray(result) || result.length !== texts.length) return res.status(502).json({error:"Unexpected translation response."});
    res.set("Cache-Control","no-store");
    return res.json({translations:result.map(x=>x.translatedText)});
  } catch (e) {
    console.error("Translation failed:",e.message);
    return res.status(504).json({error:"Translation service timed out or could not be reached."});
  }
});
app.listen(Number(process.env.PORT||3000),()=>console.log(`DecisionWise: http://localhost:${process.env.PORT||3000}`));
