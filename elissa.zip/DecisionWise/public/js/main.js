const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
function updateThemeButton(){const b=$("#themeToggle");if(!b)return;const dark=document.documentElement.dataset.theme==="dark";b.textContent=dark?"☀":"☾";b.title=dark?"Light mode":"Dark mode"}
document.documentElement.dataset.theme=localStorage.getItem("dw-theme")||(matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");updateThemeButton();
$("#themeToggle")?.addEventListener("click",()=>{const t=document.documentElement.dataset.theme==="dark"?"light":"dark";document.documentElement.dataset.theme=t;localStorage.setItem("dw-theme",t);updateThemeButton()});
$("#menuToggle")?.addEventListener("click",()=>{const open=$("#primaryNav")?.classList.toggle("open");$("#menuToggle")?.setAttribute("aria-expanded",String(!!open))});
const original=new Map();$$("[data-translate]").forEach((el,i)=>{el.dataset.translationId=String(i);original.set(String(i),el.textContent.trim())});
const language=$("#languageSelect"), notice=$("#translationNotice");
async function translate(target){
 if(!target||target==="en"){original.forEach((v,id)=>{const e=document.querySelector(`[data-translation-id="${id}"]`);if(e)e.textContent=v});if(notice)notice.textContent="";return}
 const els=$$("[data-translate]"), texts=els.map(e=>original.get(e.dataset.translationId)||e.textContent.trim());
 if(notice)notice.textContent="Translating page…";
 try{const r=await fetch("/api/translate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({texts,source:"en",target})});const d=await r.json();if(!r.ok)throw Error(d.error||"Translation failed");els.forEach((e,i)=>e.textContent=d.translations[i]);if(notice)notice.textContent=target==="rw"?"Translated to Kinyarwanda by Google Cloud Translation.":"Traduit en français par Google Cloud Translation."}
 catch(e){if(notice)notice.textContent=e.message}
}
language?.addEventListener("change",()=>{localStorage.setItem("dw-language",language.value);translate(language.value)});
if(language){language.value=localStorage.getItem("dw-language")||"en";if(language.value!=="en")translate(language.value)}
const current=location.pathname.split("/").pop()||"index.html";$$("[data-nav]").forEach(a=>{if(a.getAttribute("href")===current)a.classList.add("active")});
$("#decisionForm")?.addEventListener("submit",e=>{e.preventDefault();const result=$("#decisionResult");result.replaceChildren();result.classList.remove("hidden");const h=document.createElement("h3");h.textContent="Decision review checklist";result.append(h);const values=[["Decision",$("#decisionTitle").value],["Category",$("#decisionCategory").value],["Situation",$("#decisionSituation").value],["Desired outcome",$("#decisionGoal").value],["Options",$("#decisionOptions").value],["Next step","Compare benefits, costs, risks, feasibility, affected people, and long-term consequences."]];for(const [label,value] of values){const p=document.createElement("p"),b=document.createElement("strong");b.textContent=label+": ";p.append(b,document.createTextNode(value));result.append(p)}const n=document.createElement("div");n.className="note";n.textContent="This is an organized worksheet, not an AI-generated recommendation. Check facts and seek qualified advice for high-impact decisions.";result.append(n)});
$$("[data-demo]").forEach(b=>b.addEventListener("click",()=>{const t=$(b.dataset.demoTarget||"#demoNotice");if(t){t.textContent=b.dataset.demoMessage||"This is a front-end preview; backend functionality is not connected yet.";t.classList.remove("hidden")}}));
$$("[data-language]").forEach(b=>b.addEventListener("click",()=>{if(language){language.value=b.dataset.language;language.dispatchEvent(new Event("change"))}}));
