# DecisionWise — Multipage Website

This project contains the DecisionWise website only. Each main page is a separate HTML file, and the shared CSS and JavaScript live in their own folders.

## 1. Correct file and folder order

```text
DecisionWise/
├── package.json
├── server.js
├── .env.example
├── .gitignore
├── README.md
└── public/
    ├── index.html
    ├── how-it-works.html
    ├── categories.html
    ├── decision.html
    ├── accounts.html
    ├── messages.html
    ├── about.html
    ├── languages.html
    ├── login.html
    ├── 404.html
    ├── css/
    │   └── style.css
    └── js/
        └── main.js
```

## 2. Requirements

- Node.js 18 or newer.
- For real translation, a Google Cloud project with Cloud Translation API enabled and a valid API key. Google may require billing to be enabled.

## 3. Run locally

1. Extract the ZIP file.
2. Open the `DecisionWise` folder in VS Code.
3. Choose **Terminal → New Terminal**.
4. Run `npm install`.
5. Copy `.env.example` to a file named `.env`.
6. Add your real key in `.env`: `GOOGLE_TRANSLATE_API_KEY=your_real_key_here`.
7. Run `npm start`.
8. Open `http://localhost:3000` in Chrome.

Do not open the HTML pages directly from File Explorer. Run the server so the translation endpoint works. Keep `.env` private and never publish your API key to GitHub.

## 4. What currently works

- Separate pages connected through navigation.
- Responsive layout for desktop and mobile.
- Light/dark theme saved in the browser.
- Category links preselect the category in the decision worksheet.
- The worksheet creates an on-page checklist in the browser.
- A server endpoint sends marked interface text to Google Cloud Translation for English, French, or Kinyarwanda.

## 5. Limitations — do not skip this

This is a front-end starter, not a finished production system. Login and account creation are design previews only; accounts are not created. Admin/Super Admin permissions are not enforced. The worksheet does not save to a database. Messaging does not send or store messages. AI decision analysis is not implemented. Translation only applies to text marked `data-translate`; it does not translate every input or every unmarked element. Do not enter real passwords or confidential information.

Before public deployment, add and test secure authentication, authorization, database persistence, real messaging, AI decision logic if required, monitoring, and security controls. For sensitive legal, health, government, or safety content, have machine translations reviewed by a fluent human translator.
